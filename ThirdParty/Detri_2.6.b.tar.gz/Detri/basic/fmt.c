/* fmt.c -- Generalized formatting functions */

/* This code is based on the Release 1.0 code to Chapter 14 (Formatting),
   pages 215-239, of

   David R Hanson
   C Interfaces && Implementations - Techniques for Creating Reusable Software
   Addison-Wesley Professional Computer Series
   1997
   ISBN 0-201-49841-3 (Paperback, 544 pages)
   
   http://www.cs.princeton.edu/software/cii
   http://www.awl.com/cp/hanson.html

   For completeness, Hanson's Copyright of the original code is included
   in the test/test_fmt.c file.

   --epm, Feb-1997 */

/* NOTE:  Following Hanson's original code, this implementation treats
 *"string lengths" as regular int's, ignoring the fact that strlen() and
 * pointer arithmetic return values of size_t.  This seems to be justified,
 * because it's hard to see where a string of > 2Mb would make any sense ...
 * The macro i_len() encapsulated the size_t -> int cast.
 * --epm, May-1997
 */

/*--------------------------------------------------------------------------*/

/* Standard imports */

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <float.h>
#include <ctype.h>
#include <math.h>

/*--------------------------------------------------------------------------*/

/* Memory allocation (change to fit application) */

#define _MALLOC  malloc
#define _REALLOC realloc
#define _FREE    free

/*--------------------------------------------------------------------------*/

/* Runtime error handling (change to fit application) */

/* abort_with() is called whenever a (nonrecoverable) runtime error
   is encountered.  it can be redefined, but it better aborts execution! */

#define abort_with(MSG)             rx_error (efrmt, __FILE__, __LINE__, MSG)
#define assert(EXPR)  if (! (EXPR)) rx_error (afrmt, __FILE__, __LINE__)

void rx_error (const char *frmt, ...);
static char efrmt[] = "\n\n  RUNTIME ERROR, %s: %d\n  MESSAGE: %s\n\n";
static char afrmt[] = "\n\n  ASSERTION FAILED, %s: %d\n\n";

/*--------------------------------------------------------------------------*/

#define __INTERFACE__ "fmt.h"

/*--------------------------------------------------------------------------*/

/* Required includes */

#include <stdio.h>
#include <stdarg.h>

/*--------------------------------------------------------------------------*/

extern char *fmt_flags;

typedef void (*FMT_T) (int code, va_list *app,
                       int put (int c, void *cl), void *cl,
                       unsigned char flags[256], int width, int precision);

FMT_T fmt_register (int code, FMT_T newcvt);

/*--------------------------------------------------------------------------*/

void fmt_fmt (int put (int c, void *cl), void *cl, const char *fmt, ...);

void fmt_vfmt (int put (int c, void *cl), void *cl,
               const char *fmt, va_list ap);

void fmt_putd (const char *str, int len,
               int put (int c, void *cl), void *cl,
               unsigned char flags[], int width, int precision);

void fmt_puts (const char *str, int len,
               int put (int c, void *cl), void *cl,
               unsigned char flags[], int width, int precision);

/*--------------------------------------------------------------------------*/

void fmt_print (const char *fmt, ...);

void fmt_fprint (FILE *stream, const char *fmt, ...);

int fmt_sfmt (char *buf, int size, const char *fmt, ...);

int fmt_vsfmt (char *buf, int size, const char *fmt, va_list ap);

char *fmt_string (const char *fmt, ...);

char *fmt_vstring (const char *fmt, va_list ap);

void *fmt_newbuf (void);

void fmt_printbuf (void *buf, const char *fmt, ...);

void fmt_vprintbuf (void *buf, const char *fmt, va_list ap);

char *fmt_strbuf (void *buf);

#define fmt_free(STRPTR) do { fmt_free_f (STRPTR); STRPTR = NULL; } while (0)
void    fmt_free_f (void *str);

/*--------------------------------------------------------------------------*/

#define __IMPLEMENTATION__

/*--------------------------------------------------------------------------*/

/* Human-readable logical operators */
/*
#define &&  &&
#define ||   ||
#define !  !
#define mod  %
*/

/*--------------------------------------------------------------------------*/

/* Other useful "hacks" */

#define _noop_  _touch_ (0)
#define _touch_(ARG_CONJUNCTION)  (void) (0 && (ARG_CONJUNCTION))

/*--------------------------------------------------------------------------*/

/* The (optionally) save size_t -> int cast... */

#if 0

#define i_len(SIZE) (int) (SIZE)

#else

#define i_len(SIZE) i_len_f (SIZE)
static int i_len_f (size_t size)
{
  assert (size > (size_t) 0);
  assert (size <= (size_t) INT_MAX);
  return ((int) size);
}
    
#endif

/*--------------------------------------------------------------------------*/

#define BUFFER_MAGIC 1308000113

typedef struct buffer_struct
{
  int   magic;
  char *buf;
  char *bp;
  int   size;
} BUFFER;

/*--------------------------------------------------------------------------*/

#define zero_terminated(BUFPTR)  ((BUFPTR)->bp == '\0')

#define pad(N,C) { \
                   int nn = (N); \
                   while (nn-- > 0) \
                     put ((C), cl); \
                 } _noop_

/*--------------------------------------------------------------------------*/

static void cvt_s (int code, va_list *app,
                   int put (int c, void *cl), void *cl,
                   unsigned char flags[], int width, int precision)
     /* Format "%s" */
{
  char *str = va_arg (*app, char *);
  assert (str);
  fmt_puts (str, i_len (strlen (str)), put, cl, flags, width, precision);
  _touch_ (code);
}

/*--------------------------------------------------------------------------*/

static void cvt_d (int code, va_list *app,
                   int put (int c, void *cl), void *cl,
                   unsigned char flags[], int width, int precision)
     /* Format "%d" */
{
  int val = va_arg (*app, int);
  unsigned m;
  char buf[43];
  char *p = buf + sizeof (buf);
  if (val == INT_MIN)
    m = INT_MAX + 1U;
  else if (val < 0)
    m = -val;
  else
    m = val;
  do
    {
      *--p = m % 10 + '0';
    } while ((m /= 10) > 0);
  if (val < 0)
    *--p = '-';
  fmt_putd (p, i_len ((buf + sizeof (buf)) - p), put, cl, flags,
            width, precision);
  _touch_ (code);
}

/*--------------------------------------------------------------------------*/

static void cvt_u (int code, va_list *app,
                   int put (int c, void *cl), void *cl,
                   unsigned char flags[], int width, int precision)
     /* Format "%u" */
{
  unsigned m = va_arg (*app, unsigned);
  char buf[43];
  char *p = buf + sizeof (buf);
  do
    {
      *--p = m % 10 + '0';
    } while ((m /= 10) > 0);
  fmt_putd (p, i_len ((buf + sizeof (buf)) - p), put, cl, flags,
            width, precision);
  _touch_ (code);
}

/*--------------------------------------------------------------------------*/

static void cvt_o (int code, va_list *app,
                   int put (int c, void *cl), void *cl,
                   unsigned char flags[], int width, int precision)
     /* Format "%o" */
{
  unsigned m = va_arg (*app, unsigned);
  char buf[43];
  char *p = buf + sizeof (buf);
  do
    {
      *--p = (m&0x7) + '0';
    } while ((m>>= 3) != 0);
  fmt_putd (p, i_len ((buf + sizeof (buf)) - p), put, cl, flags,
            width, precision);
  _touch_ (code);
}

/*--------------------------------------------------------------------------*/

static void cvt_x (int code, va_list *app,
                   int put (int c, void *cl), void *cl,
                   unsigned char flags[], int width, int precision)
     /* Format "%x" */
{
  unsigned m = va_arg (*app, unsigned);
  char buf[43];
  char *p = buf + sizeof (buf);
  do
    {
      *--p = "0123456789abcdef"[m&0xf];
    } while ((m>>= 4) != 0);
  fmt_putd (p, i_len ((buf + sizeof (buf)) - p), put, cl, flags,
            width, precision);
  _touch_ (code);
}

/*--------------------------------------------------------------------------*/

static void cvt_p (int code, va_list *app,
                   int put (int c, void *cl), void *cl,
                   unsigned char flags[], int width, int precision)
     /* Format "%p" for (void *) pointer (hexadecimal) */
{
  unsigned long m = (unsigned long) va_arg (*app, void *);
  char buf[43];
  char *p = buf + sizeof (buf);
  precision = INT_MIN;
  do
    {
      *--p = "0123456789abcdef"[m & 0xf];
    } while ((m>>= 4) != 0);
  fmt_putd (p, i_len ((buf + sizeof (buf)) - p), put, cl, flags,
      width, precision);
  _touch_ (code);
}

/*--------------------------------------------------------------------------*/

static void cvt_c (int code, va_list *app,
                   int put (int c, void *cl), void *cl,
                   unsigned char flags[], int width, int precision)
     /* Format "%c" */
{
  if (width == INT_MIN)
    width = 0;
  if (width < 0)
    {
      flags['-'] = 1;
      width = -width;
    }
  if (! flags['-'])
    pad (width - 1, ' ');
  put ((unsigned char) va_arg (*app, int), cl);
  if ( flags['-'])
    pad (width - 1, ' ');
  _touch_ (code && precision);
}

/*--------------------------------------------------------------------------*/

static void cvt_f (int code, va_list *app,
                   int put (int c, void *cl), void *cl,
                   unsigned char flags[], int width, int precision)
     /* Formats "%f", "%e", "%g" */
{
  char buf[DBL_MAX_10_EXP+1+1+99+1];
  if (precision < 0)
    precision = 6;
  if ((code == 'g') && (precision == 0))
    precision = 1;
  {
    static char fmt[] = "%.dd?";
    assert (precision <= 99);
    fmt[4] = code;
    fmt[3] =      precision % 10 + '0';
    fmt[2] = (precision/10) % 10 + '0';
    sprintf (buf, fmt, va_arg (*app, double));
  }
  fmt_putd (buf, i_len (strlen (buf)), put, cl, flags, width, precision);
}

/*--------------------------------------------------------------------------*/

char *fmt_flags = "-+ 0";

static FMT_T cvt[256] =
{
  0,     0,      0,     0,     0,     0,     0,     0,     /*   0-  7 */
  0,     0,      0,     0,     0,     0,     0,     0,     /*   8- 15 */
  0,     0,      0,     0,     0,     0,     0,     0,     /*  16- 23 */
  0,     0,      0,     0,     0,     0,     0,     0,     /*  24- 31 */
  0,     0,      0,     0,     0,     0,     0,     0,     /*  32- 39 */
  0,     0,      0,     0,     0,     0,     0,     0,     /*  40- 47 */
  0,     0,      0,     0,     0,     0,     0,     0,     /*  48- 55 */
  0,     0,      0,     0,     0,     0,     0,     0,     /*  56- 63 */
  0,     0,      0,     0,     0,     0,     0,     0,     /*  64- 71 */
  0,     0,      0,     0,     0,     0,     0,     0,     /*  72- 79 */
  0,     0,      0,     0,     0,     0,     0,     0,     /*  80- 87 */
  0,     0,      0,     0,     0,     0,     0,     0,     /*  88- 95 */
  0,     0,      0, cvt_c, cvt_d, cvt_f, cvt_f, cvt_f,     /*  96-103 */
  0,     0,      0,     0,     0,     0,     0, cvt_o,     /* 104-111 */
  cvt_p, 0,      0, cvt_s,     0, cvt_u,     0,     0,     /* 112-119 */
  cvt_x, 0,      0,     0,     0,     0,     0,     0      /* 120-127 */
};

/*--------------------------------------------------------------------------*/

FMT_T fmt_register (int code, FMT_T newcvt)
     /* Register user-define format */
{
  FMT_T old;
  assert ((0 < code) && (code < (int) (sizeof (cvt) / sizeof (cvt[0]))));
  old = cvt[code];
  cvt[code] = newcvt;
  return (old);
}

/*--------------------------------------------------------------------------*/

static int outc (int c, void *cl)
     /* Put function for file */
{
  FILE *f = cl;
  return (putc (c, f));
}

/*--------------------------------------------------------------------------*/

static int insert (int c, void *cl)
     /* Put function for string, bounded */
{
  BUFFER *p = cl;
  if (p->bp >= p->buf + p->size - 1)
    abort_with ("String formatting overflow");
  p->bp[0] = c;
  p->bp++;
  p->bp[0] = '\0';  /* keep it zero-teminated at all time */
  return (c);
}

/*--------------------------------------------------------------------------*/

static int append (int c, void *cl)
     /* Put function for string, unbounded */
{
  BUFFER *p = cl;
  if (p->bp >= p->buf + p->size - 1)
    {
      p->buf = _REALLOC (p->buf, 2 * p->size);
      if (! p->buf)
        abort_with ("String formatting: buffer reallocation failed");
      p->bp = p->buf + p->size;
      p->size *= 2;
    }
  p->bp[0] = c;
  p->bp++;
  p->bp[0] = '\0';  /* keep it zero-teminated at all time */
  return (c);
}

/*--------------------------------------------------------------------------*/

void fmt_fmt (int put (int c, void *cl), void *cl, const char *fmt, ...)
     /* Main fmt function */
{
  va_list ap;
  va_start (ap, fmt);
  fmt_vfmt (put, cl, fmt, ap);
  va_end (ap);
}

/*--------------------------------------------------------------------------*/

void fmt_vfmt (int put (int c, void *cl), void *cl,
               const char *fmt, va_list ap)
     /* Main fmt function, va_list version */
{
  assert (put);
  assert (fmt);
  while (*fmt)
    if ((*fmt != '%') || (*++fmt == '%'))
      put ((unsigned char) *fmt++, cl);
    else
      {
        unsigned char c, flags[256];
        int width = INT_MIN, precision = INT_MIN;
        memset (flags, 0, sizeof (flags));
        if (fmt_flags)
          {
            unsigned char c = *fmt;
            for (; c && strchr (fmt_flags, c); c = *++fmt)
              {
                assert (flags[c] < 255);
                flags[c]++;
              }
          }
        if ((*fmt == '*') || (isdigit (*fmt)))
          {
            int n;
            if (*fmt == '*')
              {
                n = va_arg (ap, int);
                assert (n != INT_MIN);
                fmt++;
              }
            else
              {
                for (n = 0; isdigit (*fmt); fmt++)
                  {
                    int d = *fmt - '0';
                    assert (n <= (INT_MAX - d)/10);
                    n = 10*n + d;
                  }
              }
            width = n;
          }
        if ((*fmt == '.') && ((*++fmt == '*') || isdigit (*fmt)))
          {
            int n;
            if (*fmt == '*')
              {
                n = va_arg (ap, int);
                assert (n != INT_MIN);
                fmt++;
              }
            else
              {
                for (n = 0; isdigit (*fmt); fmt++)
                  {
                    int d = *fmt - '0';
                    assert (n <= (INT_MAX - d)/10);
                    n = 10*n + d;
                  }
              }
            precision = n;
          }
        c = *fmt++;
        if (! cvt[c])
          { /* Unregistered formatting character */
            char msg[80];
            sprintf (msg, "Formatting failed: unknown || unregistered %s '%c'",
                     "format code", c);
            abort_with (msg);
          }
        (*cvt[c]) (c, &ap, put, cl, flags, width, precision);
      }
}

/*--------------------------------------------------------------------------*/

void fmt_putd (const char *str, int len,
               int put (int c, void *cl), void *cl,
               unsigned char flags[], int width, int precision)
     /* "%d" conversion function, exported for reuse */
{
  int sign;
  assert (str);
  assert (len != 0);
  assert (flags);
  if (width == INT_MIN)
    width = 0;
  if (width < 0)
    {
      flags['-'] = 1;
      width = -width;
    }
  if (precision >= 0)
    flags['0'] = 0;
  if ((len > 0) && ((*str == '-') || (*str == '+')))
    {
      sign = *str++;
      len--;
    }
  else if (flags['+'])
    sign = '+';
  else if (flags[' '])
    sign = ' ';
  else
    sign = 0;
  {
    int n;
    if (precision < 0)
      precision = 1;
    if (len < precision)
      n = precision;
    else if ((precision == 0) && (len == 1) && (str[0] == '0'))
      n = 0;
    else
      n = len;
    if (sign)
      n++;
    if (flags['-'])
      {
        if (sign)
          put (sign, cl);
      }
    else if (flags['0'])
      {
        if (sign)
          put (sign, cl);
        pad (width - n, '0');
      }
    else
      {
        pad (width - n, ' ');
        if (sign)
          put (sign, cl);
      }
    pad (precision - len, '0');
    {
      int i;
      for (i = 0; i < len; i++)
        put ((unsigned char) *str++, cl);
    }
    if (flags['-'])
      pad (width - n, ' ');
  }
}

/*--------------------------------------------------------------------------*/

void fmt_puts (const char *str, int len,
               int put (int c, void *cl), void *cl,
               unsigned char flags[], int width, int precision)
     /* "%s" conversion function, exported for reuse */
{
  assert (str);
  assert (len >= 0);
  assert (flags);
  if (width == INT_MIN)
    width = 0;
  if (width < 0)
    {
      flags['-'] = 1;
      width = -width;
    }
  if (precision >= 0)
    flags['0'] = 0;
  if ((precision >= 0) && (precision < len))
    len = precision;
  if (! flags['-'])
    pad (width - len, ' ');
  {
    int i;
    for (i = 0; i < len; i++)
      put ((unsigned char)*str++, cl);
  }
  if ( flags['-'])
    pad (width - len, ' ');
}

/*--------------------------------------------------------------------------*/

void fmt_print (const char *fmt, ...)
     /* Standard printf, reimplemented */
{
  va_list ap;
  va_start (ap, fmt);
  fmt_vfmt (outc, stdout, fmt, ap);
  va_end (ap);
}

/*--------------------------------------------------------------------------*/

void fmt_fprint (FILE *stream, const char *fmt, ...)
     /* Standard fprintf, reimplemented */
{
  va_list ap;
  va_start (ap, fmt);
  fmt_vfmt (outc, stream, fmt, ap);
  va_end (ap);
}

/*--------------------------------------------------------------------------*/

int fmt_sfmt (char *buf, int size, const char *fmt, ...)
     /* Like standard sprintf, but strinctly operating on buf[0..size-1];
        issues runtime error if overflow */
{
  va_list ap;
  int len;
  va_start (ap, fmt);
  len = fmt_vsfmt (buf, size, fmt, ap);
  va_end (ap);
  return (len);
}

/*--------------------------------------------------------------------------*/

int fmt_vsfmt (char *buf, int size, const char *fmt, va_list ap)
     /* Same as above, va_list version */
{
  BUFFER cl;
  assert (buf);
  assert (size > 0);
  assert (fmt);
  cl.magic = 0;
  cl.size = size;
  cl.buf = cl.bp = buf;
  cl.buf[0] = '\0';
  fmt_vfmt (insert, &cl, fmt, ap);
  cl.bp[0] = '\0';
  return (i_len (cl.bp - cl.buf - 1));
}

/*--------------------------------------------------------------------------*/

char *fmt_string (const char *fmt, ...)
     /* Like standard sprintf, but automatically allocate string large enough
        to hold formatted result; issues runtime error if no more memory;
        application must deallocate, best via fmt_free() macro */
{
  va_list ap;
  char *str;
  assert (fmt);
  va_start (ap, fmt);
  str = fmt_vstring (fmt, ap);
  va_end (ap);
  return (str);
}

/*--------------------------------------------------------------------------*/

char *fmt_vstring (const char *fmt, va_list ap)
     /* Same as above, va_list version */
{
  BUFFER cl;
  assert (fmt);
  cl.magic = 0;
  cl.size = 256;
  cl.buf = cl.bp = _MALLOC (cl.size);
  cl.buf[0] = '\0';
  if (! cl.buf)
    abort_with ("String formatting: memory allocation failed");
  fmt_vfmt (append, &cl, fmt, ap);
  cl.bp[0] = '\0';
  cl.buf = _REALLOC (cl.buf, cl.bp - cl.buf);
  if (! cl.buf)
    abort_with ("String formatting: memory reallocation failed");
  return (cl.buf);
}

/*--------------------------------------------------------------------------*/

void *fmt_newbuf (void)
     /* Open new buffer for fmt_printbuf() && fmt_getbuf();
        application must deallocate via fmt_free() macro */
{
  BUFFER *p = _MALLOC (sizeof (BUFFER));
  if (p)
    {
      p->magic = BUFFER_MAGIC;
      p->size = 256;
      p->buf = p->bp = _MALLOC (p->size);
      p->buf[0] = '\0';
      if (p->buf)
        return ((void *) p);
    }
  abort_with ("Buffer allocation failed");
  return ((void *) p);
}

/*--------------------------------------------------------------------------*/

void fmt_printbuf (void *buf, const char *fmt, ...)
     /* printf-like function to write into buffer created by fmt_newbuf() */
{
  va_list ap;
  assert (fmt);
  va_start (ap, fmt);
  fmt_vprintbuf (buf, fmt, ap);
  va_end (ap);
}

/*--------------------------------------------------------------------------*/

void fmt_vprintbuf (void *buf, const char *fmt, va_list ap)
     /* Same as above, va_list version */
{
  BUFFER *p = buf;
  assert (fmt);
  assert (buf);
  assert (p->magic == BUFFER_MAGIC);
  assert (p->buf);
  assert (p->bp[0] == '\0');
  fmt_vfmt (append, p, fmt, ap);
  p->bp[0] = '\0';
}

/*--------------------------------------------------------------------------*/

char *fmt_strbuf (void *buf)
     /* Return pointer to the string of the buffer */
{
  BUFFER *p = buf;
  assert (buf);
  assert (p->magic == BUFFER_MAGIC);
  assert (p->buf);
  assert (p->bp[0] == '\0');
  return (p->buf);
}

/*--------------------------------------------------------------------------*/

void fmt_free_f (void *str)
     /* The fmt_free() macros calls this to free a (char *) || (BUFFER *)
        as returned by fmt_[v]string() of fmt_newbuf() */
{
  if (str)
    {
      BUFFER *p = str;
      if (p->magic == BUFFER_MAGIC)
        {
          _FREE (p->buf);
          _FREE (p);
        }
      else
        { /* just free it as a (char *) */
          _FREE (str);
        }
    }
}
