/* rx/system.c -- A handful of system routines */

/*--------------------------------------------------------------------------*/

/* Interface: see rx.h */

#include "rx.h"

/*--------------------------------------------------------------------------*/

#define __IMPLEMENTATION__

/*--------------------------------------------------------------------------*/

/* Imports */

#include <time.h>

char *ctime (const time_t *clock);  /* Why isn't this always in <time.h> ???
                                       <-- actually, in prev. versions, I
                                       forgot to include <time.h>, so this
                                       might be redundant now!! */

#define __has_gethostname__ /* Unix function gethostname() is not ANSI */
#if defined(__MWERKS__) || defined(macintosh)
# undef __has_gethostname__
#endif

#if defined(__has_gethostname__)
 int gethostname (char *name, int namelen);
#endif

#include "fmt.h"

/*--------------------------------------------------------------------------*/

/* Local buffer */

#define BUFLEN  512
static char buf[BUFLEN];

/*--------------------------------------------------------------------------*/

/* Error hook: local variable, global constant*/

static   void (* hook) (const char []) = NULL;
void (* rx__null_hook) (const char []) = NULL;

/*--------------------------------------------------------------------------*/

void rx_system (const char *frmt, ...)
     /* Procedure rx_system (frmt [, arg] ...) executes a system command,
        where the command string is given in a sprintf-like fashion */
{ 
  va_list argp;
  char *cmd;
  int result;

  va_start (argp, frmt);
  cmd = fmt_vstring (frmt, argp);
  va_end (argp);

  result = system (cmd);
  if (result != 0)
    print ("WARNING: rx_system(\"%s\") status=%d\n", cmd, result);
  fmt_free (cmd);
}

/*--------------------------------------------------------------------------*/

void rx_error (const char *frmt, ...)
     /* Procedure rx_error (frmt [, arg] ...) produces a message in the
        sprintf-like fashion.  Then is either aborts, or passed on the
        message to the current error hook */
{ 
  va_list argp;
  char *msg = buf; /* Note: we could use fmt_string() for message formatting;
                      but what if there is an error in fmt ?? */
  
  va_start (argp, frmt);
  (void) vsprintf (buf, frmt, argp);
  va_end (argp);

  if (hook)
    { /* call hook with msg */
      hook (msg);
    }
  else
    { /* print error message and abort execution (with coredump) */
      fprint (stderr, "%s\n", msg);
      abort ();
    }
}  

/*--------------------------------------------------------------------------*/

void rx_error_hook (void (* user_error) (const char msg[]))
     /* To specify an error hook call rx_error_hook (my_error) assuming
        my_error is a pointer to a function:
        .
        .            void my_error (const char error_message[])
        .            { ... }
        .
        With this, rx_error() will generate the error_message and pass it
        to my_error().  This function might then do some cleanup and/or cause
        segmentation fault for dbx.  Use rx_error_hook (NULL_HOOK) to get
        default behaviour back */
{
  hook = user_error;
}


/*--------------------------------------------------------------------------*/

double rx_utime (void)
     /* Returns user seconds elapsed since start of process */
{
  return ((double) clock () / CLOCKS_PER_SEC);
}

/*--------------------------------------------------------------------------*/

char* rx_hostname (void)
     /* Returns (static!) pointer to hostname string */
{
#if defined __has_gethostname__
  //(void) gethostname (buf, BUFLEN); //DAVID
#else
  sprint (buf, "Unknown.Host");
#endif
  return (buf);
}

/*--------------------------------------------------------------------------*/

char* rx_date (void)
     /* Gives date and time information in ASCII */
{
  time_t clock;
  char * ptr;
  int i;
  clock = time ((time_t *) 0);
  ptr = ctime (&clock);
  i = 1;
  while (*ptr && (i < BUFLEN))
    {
      buf[i-1] = *ptr;
      i ++;
      ptr ++;
    }
  buf[i-1] = *ptr;
  if (buf[i-2] == '\n')
    buf[i-2] = 0;
  return (buf);
}

/*--------------------------------------------------------------------------*/

double rx_seconds (void)
     /* Returns seconds elapsed since 1-Jan-1900. */
{
  time_t tp;
  (void) time (&tp);
  return (difftime (tp, (time_t) 0));
}

/*--------------------------------------------------------------------------*/

int rx_seed (void)
     /* Returns some int seed for random generators */
{
  return ((int) (1000.0 * rx_seconds ()));
}
