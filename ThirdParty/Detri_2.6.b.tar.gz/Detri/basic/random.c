/* rx/random.c -- Routines to encapsulate the random generator. */

/* NOTE: In future, we ought to have a "home-baked" random generator as well,
 *       for the purpose of porting and testing!
 */

/*--------------------------------------------------------------------------*/

/* Interface: see rx.h */

#include "rx.h"

/*--------------------------------------------------------------------------*/

#define __IMPLEMENTATION__

/*--------------------------------------------------------------------------*/

/* Imports */

/* NOTE: The "better" random generator seems to exist on most (Unix) systems,
   even though ANSI C officially includes only the "old" rand() and srand()
   routines... */

#if defined(__irix64)
 long random (void);
 int srandom (int seed);
#endif

#if defined(__MWERKS__) || defined(macintosh)
# define  random  rand
# define srandom srand
#endif

/* ALSO NOTE: This is not guaranteed to be thread-safe! */
/* OR BETTER: This is guaranteed not to be thread-safe! */

/*--------------------------------------------------------------------------*/

long rx_random (void)
{
  return (rand ()); //DAVID random -> rand
}

void rx_srandom (int seed)
{
  srand (seed);  /* srandom() returns undefined value, if at all */ //DAVID srandom -> srand
}
