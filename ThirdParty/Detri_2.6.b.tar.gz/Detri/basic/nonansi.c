/* rx/nonansi.c -- Substitutes for functions that are sometimes missing...
 *                 because they are not in the ANSI standard
 *                 PLUS: Some int math... so that the file is never empty. */

/*--------------------------------------------------------------------------*/

#include "rx.h"

/*--------------------------------------------------------------------------*/

int rx_ipower (int x, int y)
     /* Returns (int) x "to the power of" y, assuming y >= 0.
        Time complexity: O (log_2 (y)).
        NOTE: You better make sure that Abs (x^y) < INT_MAX. */
{
  int aux;
  if (y == 0)
    return (1);
  else if (Odd (y))
    return (x * rx_ipower (x, y - 1));
  else
    {
      aux = rx_ipower (x, y / 2);
      return (aux * aux);
    }
}

/*--------------------------------------------------------------------------*/

//#if defined(sgi) || defined(sun) || defined(hpux) || defined(__convex__) \
|| defined(__alpha) || defined(_IBMR2) || defined(NeXT) ||  defined(linux) \
|| defined(__MWERKS__) || defined(macintosh)

double log2 (double x)
{
  return (log (x) / log (2.0));
}

double exp2 (double x)
{
  return (exp (x * log (2.0)));
}

double exp10 (double x)
{
  return (exp (x * log (10.0)));
}

//#endif

/*--------------------------------------------------------------------------*/

#if ( defined (sgi) && !defined (_SGI_SOURCE) && defined (__ANSI_CPP__) )

double cbrt (double x)
{
  static double one_third = 1.0 / 3.0;
  return (pow (x, one_third));
}

#endif
