/*
 * color.c -- Routines for handling the assignment of color to vertices
 *            in the Delaunay triangulation.
 *
 * author -- Mike Facello
 */

#include "dt.h"

/* variables for storing the point colors */

static int *colors;
static int file_loaded = FALSE;
/* static char *color_file; */

/*--------------------------------------------------------------------------*/

void dt_load_color (char *color_file, int n)
{
  FILE *cf = rx_fopen (color_file, "r");
  int io, i, c, lines = 0;
  char *r;
  int limit = FALSE;

  if (! colors)
    colors = MALLOC(int, n + 1);
  BZERO(colors, int, n + 1);

  while ((r = basic_cb_getline (cf)))
    {
      lines ++;
      if (rx_strip (r) && (r[0] != '#'))
        {
          io = sscanf (r, "%d %d", &i, &c);
          if (io != 2)
            rx_error ("dt_load_color: %s at line %d\n"
                      "error in color file", lines);
          colors[i] = c;
        }
    }
  rx_fclose (cf);

#ifdef ORIGINAL
  upfor (lines, 1, n)
    {
      r = basic_cb_getline (cf);
      io = sscanf (r, "%d %d", &i, &c);
      if (io != 2)
        rx_error ("dt_load_color: %s at line %d\n"
                  "error in color file", lines);
      colors[i] = c;
    }
#endif

  file_loaded = TRUE;
}

/*--------------------------------------------------------------------------*/

int dt_get_color (int i)
{
  if (file_loaded)
    return (colors[i]);
  else
    return i;
}

/*--------------------------------------------------------------------------*/

void dt_kill_color (void)
{
  if (colors)
    FREE (colors);
}


#ifdef OLD_CODE
      else if (is_command (&data, r, "color", 5))
        { /* # title: %s */
          r = rx_strip (index (r, 'r') + 1);
          if (r)
            {
              int i = -1;
              color_file = STRDUP (r);
              do { i ++; } until (color_file[i] == '\n');
              color_file[i] = 0;
              do_color = TRUE;
            }
        }

#endif
