/* detri/search.c --- Simple but efficient point location in (Delaunay) Tri. */

/* Variant:
 * - adaptive sample size (average search length)
 * - randomized "next face" selection
 */

/*--------------------------------------------------------------------------*/

#include "trist.h"

#ifdef __DEBUG__
 int dt_test_open_tetra (int a, int x, int y, int z, int o);
 int dt_test_triangle (int ef, int x, int y, int z);
#endif

#define print_TEST print

/*--------------------------------------------------------------------------*/

/* default values of "constants" for adaptive sample size */
/* see searchx/README */

static double c0 = 1.5;
static double c1 = 7.0;
static double c2 = 8.0 * 7.0;
static double c3 = 2.0;
static int    n = 1000;  /* Why not? */

/*--------------------------------------------------------------------------*/

/* locals */

static double distance (int ef, int p);
static double square (double x);

/* to keep track of work done */
static int positive3_tests = 0;
static int tets_visited = 0;
static int calls = 0;
static int ups = 0, ups_mx = 0, downs = 0;

/*--------------------------------------------------------------------------*/

/* timer / clock_t (only really used if __NO_CLOCK__ is undefined */

#define __NO_CLOCK__

#include <time.h>

static clock_t t_jump = 0;
static clock_t t_walk = 0;

#ifdef __NO_CLOCK__
#  define TIME_IT() ((clock_t) 0)
#else
#  define TIME_IT() clock ()
#endif

/*--------------------------------------------------------------------------*/

void trist_search_set (const char id[], ...)
     /* Sets constans for adaptive sample size.
        The id string decides what is done.
        For:                         Parameters:
        id == "Constants c1,c2,c3=", double, double, double
        id == "Tune n=",             int
        */
{
  va_list argp;
  va_start (argp, id);
  switch (id[0])
    {
     case 'C':
      {
        c1 = va_arg (argp, double);
        c2 = va_arg (argp, double);
        c3 = va_arg (argp, double);
        break;
      }
     case 'T':
      {
        n = va_arg (argp, int);
        break;
      }
     default:
      rx_error ("trist_search_set (\"%s\", ...) ! recognized!\n", id);
    }
  va_end (argp);
}

/*--------------------------------------------------------------------------*/

int trist_search (int p)
     /* Point location for query point p in (Delaunay) triangulation of
        current Trist.
        -
        The result is an edgefacet ef with p in ef^+.  If it's a hull facet,
        then p lies outside the convex hull; otherwise, the point lies inside
        the tetrahedron represented by ef.
        -
        Has to be used together with trist_search_set ("Tune n=", <n>).
        && the optional: trist_search_set ("Constants c1,c2,c3=", ...).
        -
        Uses jump'n'walk strategy with adaptive size of random sample.
        Expected search time = O(n^{1/4}).
        -
        Set q4 = n^{1/4}.  The initial sample size k == c1 * q4,
        but will be adapted (while enforcing range:  c1 * q4 <= k <= c2 * q4)
        such that: q4 <= avgerage search length <= c3 * q4.
        */
{
  static int k = 1;
  double q4 = pow ((double) n, 0.25);
  int k_min = (int) (c1 * q4 + 0.5);
  int k_max = (int) (c2 * q4 + 0.5);
  double dist, dist_prime;
  int result, a, b, c, i, ef, ef_prime, last = trist_current ()->last_triangle;
  clock_t t;
  ;
#define RANDOM_FACET(X)  /* Input/output: int x. */              \
  do                                                              \
    {                                                              \
      X = ((int) rx_random () % last) + 1;                           \
    } until (! trist_deleted (X));  /* Result: random triangle */  \
  X = EdFacet (X, 0)
  ;
  calls ++;
  k = Max (k, k_min);
  t_jump -= TIME_IT ();
  ;
  /* Jump: Select "good" candidate using k random samples,
   *       taking the closest one using quick'n'dirty floating-point distance()
   */
  RANDOM_FACET (ef_prime);
  dist_prime = distance (ef_prime, p);
  upfor (i, 2, k)
    {
      RANDOM_FACET (ef);
      dist = distance (ef, p);
      if (dist < dist_prime)
        {
          ef_prime = ef;
          dist_prime = dist;
        }      
    }
  trist_triangle (ef_prime, &a, &b, &c);
  if (! sos_positive3 (p, a, b, c))
    {
      ef_prime = Sym (ef_prime);
      trist_triangle (ef_prime, &a, &b, &c);
    }
  positive3_tests ++;
  t_jump += (t = TIME_IT ());
  t_walk -=  t;
  ;
  /* Walk: starting search at "good" candidate, "walk" towards target,
   *       && return result.
   */
  result = trist_search_walk (p, ef_prime, a, b, c);
  t_walk += TIME_IT ();
  ;
#if __DEBUG__
  trist_triangle (result, &a, &b, &c);
  if (trist_hull_facet (result))
    { /* p is on CH && visible from v, right? */
      Assert (sos_positive3 (p, a, b, c));
    }
  else
    { /* p is inside tetrahedron ef^+, right? */
      i = Dest (Enext (Fnext (result)));
      (void) dt_test_open_tetra (Fnext (result), a, b, c, i);
      Assert (    sos_positive3 (p, a, b, c)
              && sos_positive3 (p, b, a, i)
              && sos_positive3 (p, c, b, i)
              && sos_positive3 (p, a, c, i));
      }
#endif
  ;
  { /* Adaptive sample size */
#ifdef __NO_CLOCK__
    /* Variant 1: maintain good avergae search length */
    double avg = ((double) tets_visited) / ((double) calls);
    if ((k < k_max) && (avg > c3 * q4))
      {
        k = (int) (c0 * k + 0.5);
        k = Min (k, k_max);
        //print_TEST ("UP: k = %d = %lf * %lf\n", k, (double) k / q4, q4);
        ups ++;
      }
    else if ((k > k_min) && (avg < q4))
      {
        k = (int) ((double) k / c0 + 0.5);
        k = Max (k, k_min);
        //print_TEST ("DOWN: k = %d = %lf * %lf\n", k, (double) k / q4, q4);
        downs ++;
      }
#else
    /* Variant 2: Try to "even out" CPU time */
    /* Discarded! See searchx/README.2 */
    if ((k < k_max) && (t_jump < 0.9 * t_walk))
      {
        k = (int) (c0 * k + 0.5);
        k = Min (k, k_max);
        //print_TEST ("UP: k = %d = %lf * %lf\n", k, (double) k / q4, q4);
        ups ++;
      }
    else if ((k > k_min) && (t_jump > 1.1 * t_walk))
      {
        k = (int) ((double) k / c0 + 0.5);
        k = Max (k, k_min);
        //print_TEST ("DOWN: k = %d = %lf * %lf\n", k, (double) k / q4, q4);
        downs ++;
      }
#endif
  }  
  ;
  return (result);
#undef RANDOM_FACET
}

/*--------------------------------------------------------------------------*/

int trist_search_walk (int p, int ef, int i, int j, int k)
     /* The "walk" routine.
        It locates point p within (Delaunay) triangulation of current Trist,
        assuming ef == (i,j,k) && sos_positive3 (p, i, j, k) == TRUE.
        The result... see trist_search(). */
     /* Version: Loop, randomized "next face" selection. */
     /* NOTE: this randomization assures that "the infinite loop is broken
        with high probability" ... || as PH put it: it "is broken with
        probability infinitesimally less than certainty" */
{
  static char sequence[6][4] = { "ABC", "BCA", "CAB", "ACB", "CBA", "BAC" };
  char *ptr;
  int ef_1, ef_2, ef_3, o;
  int emergency_break = (int) (1.2 * trist_max ());
  int not_done = TRUE;
  while (not_done)
    { /* loop (1) simulating tail recursion */
      emergency_break --;
      Assert_always (emergency_break > 0);
      ;
      Assert (dt_test_triangle (ef, i, j, k) && sos_positive3 (p, i, j, k));
      if (trist_hull_facet (ef))
        { /* Found!  Outside convex hull. */
          not_done = FALSE;
        }
      else
        {
          ef_1 = Fnext (ef);
          ef_2 = Fnext (ef = Enext (ef));
          ef_3 = Fnext (ef = Enext (ef));
          o = Dest (Enext (ef_1));
          tets_visited ++;
          ;
          ptr = sequence[rx_random () % 6];
          while (ptr)
            { /* loop (2) selecting "next face" randomly */
              switch (*ptr)
                { 
                 case 'A':
                  {
                    if (sos_positive3 (p, i, j, o))
                      { /* recursion: trist_search_walk (p, ef_1, i, j, o) */
                        ef = ef_1;
                        k = o;
                        ptr = NULL;  /* break (2) */
                      }
                    else
                      ptr ++;
                    positive3_tests += 1;
                    break;
                  }
                 case 'B':
                  {
                    if (sos_positive3 (p, j, k, o))
                      { /* recursion: trist_search_walk (p, ef_2, j, k, o) */
                        ef = ef_2;
                        i = j;
                        j = k;
                        k = o;
                        ptr = NULL;  /* break (2) */
                      }
                    else
                      ptr ++;
                    positive3_tests += 1;
                    break;
                  }
                 case 'C':
                  {                 
                    if (sos_positive3 (p, k, i, o))
                      { /* recursive: trist_search_walk (p, ef_3, k, i, o) */
                        ef = ef_3;
                        j = i;
                        i = k;
                        k = o;
                        ptr = NULL;  /* break (2) */
                      }
                    else
                      ptr ++;
                    positive3_tests += 1;
                    break;
                  }
                 case '\0':
                  { /* Found!  Inside tetrahedron. */
                    ptr = NULL;        /* break (2) */
                    not_done = FALSE;  /*   && (1) */
                    break;
                  }
                }
            }
        }
    }
  return (ef);
}

/*--------------------------------------------------------------------------*/

static double distance (int ef, int p)
     /* Returns FP "distance" of edfacet ef to p. (minimum) */
{
  int a, b, c;
  double d, da, db, dc;
  double p1 = sos_fp (p, 1);
  double p2 = sos_fp (p, 2);
  double p3 = sos_fp (p, 3);
  trist_triangle (ef, &a, &b, &c);
  da = (  square (p1 - sos_fp (a, 1))
        + square (p2 - sos_fp (a, 2))
        + square (p3 - sos_fp (a, 3)));
  db =  (  square (p1 - sos_fp (b, 1))
         + square (p2 - sos_fp (b, 2))
         + square (p3 - sos_fp (b, 3)));
  dc = (  square (p1 - sos_fp (c, 1))
        + square (p2 - sos_fp (c, 2))
        + square (p3 - sos_fp (c, 3)));
  d = Min (da, db);
  return (Min (d, dc));
}

/*--------------------------------------------------------------------------*/

static double square (double x)
{
  return (x * x);
}    

/*--------------------------------------------------------------------------*/

int trist_search_counter (const char name[])
     /* Returns (accumulated) number of ...
        sos_positive3() tests & tetrahedra visited. */
{
  if (strcmp (name, "tests") == 0)
    return (positive3_tests);
  else  if (strcmp (name, "tets") == 0)
    return (tets_visited);
  else if (strcmp (name, "downs") == 0)
    return (downs);
  else if (strcmp (name, "ups") == 0)
    return (ups);
  else if (strcmp (name, "ups_mx") == 0)
    return (ups_mx);
  else if (strcmp (name, "time_ratio_1000") == 0)
    {
#ifndef __NO_CLOCK__
      print_TEST ("\nSEARCH CLOCK: %d vs %d\n\n", t_jump, t_walk);
#endif
      if (t_jump == 0)
        return (-1);
      else
        return ((int) (1000.0 * t_walk / t_jump));
    }
  else
    return (0);
}
